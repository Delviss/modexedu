<?php
/**
 * Plugin support: Contact Form 7
 *
 * @package WordPress
 * @subpackage ThemeREX Addons
 * @since v1.5
 */


// Check if Contact Form 7 installed and activated
if ( !function_exists( 'trx_addons_exists_woocommerce_wishlist' ) ) {
	function trx_addons_exists_woocommerce_wishlist() {
        return defined( 'YITH_WCWL_INIT' );
	}
}


// One-click import support
//------------------------------------------------------------------------

// Check plugin in the required plugins
if ( !function_exists( 'trx_addons_woocommerce_wishlist_importer_required_plugins' ) ) {
	if (is_admin()) add_filter( 'trx_addons_filter_importer_required_plugins',	'trx_addons_woocommerce_wishlist_importer_required_plugins', 10, 2 );
	function trx_addons_woocommerce_wishlist_importer_required_plugins($not_installed='', $list='') {
		if (strpos($list, 'yith-woocommerce-wishlist')!==false && !trx_addons_exists_woocommerce_wishlist() )
			$not_installed .= '<br>' . esc_html__('Woocommerce Wishlist', 'trx_addons');
		return $not_installed;
	}
}

// Set plugin's specific importer options
if ( !function_exists( 'trx_addons_woocommerce_wishlist_importer_set_options' ) ) {
	if (is_admin()) add_filter( 'trx_addons_filter_importer_options',	'trx_addons_woocommerce_wishlist_importer_set_options' );
	function trx_addons_woocommerce_wishlist_importer_set_options($options=array()) {
		if ( trx_addons_exists_woocommerce_wishlist() && in_array('yith-woocommerce-wishlist', $options['required_plugins']) ) {
			$options['additional_options'][] = 'yith_wcwl_%';
		}
		return $options;
	}
}

// Add checkbox to the one-click importer
if ( !function_exists( 'trx_addons_woocommerce_wishlist_importer_show_params' ) ) {
	if (is_admin()) add_action( 'trx_addons_action_importer_params',	'trx_addons_woocommerce_wishlist_importer_show_params', 10, 1 );
	function trx_addons_woocommerce_wishlist_importer_show_params($importer) {
		if ( trx_addons_exists_woocommerce_wishlist() && in_array('yith-woocommerce-wishlist', $importer->options['required_plugins']) ) {
			$importer->show_importer_params(array(
				'slug' => 'yith-woocommerce-wishlist',
				'title' => esc_html__('Import Woocommerce Wishlist', 'trx_addons'),
				'part' => 1
			));
		}
	}
}

?>